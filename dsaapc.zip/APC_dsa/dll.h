#ifndef DLL_H
#define DLL_H

#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 1
#define FAILURE 0
#define LIST_EMPTY -1

#define POSITIVE 1
#define NEGATIVE -1
typedef struct node
{
	int data;
	struct node *prev;
	struct node *next;
}Dlist;

int insert_last(Dlist **head, Dlist **tail, int data);
int print_list(Dlist *head);
int delete_first(Dlist **head);
int delete_list(Dlist **head, Dlist **tail);
int list_length(Dlist *head);
int insert_at_first(Dlist **head, Dlist **tail, int data);
int compare_lists(Dlist *head1, Dlist *head2);


void swap_operand(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2);
void copy_list(Dlist **head, Dlist **tail, Dlist **copy_head, Dlist **copy_tail);
void add(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **result_head, Dlist **result_tail);
void multiplication(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **head_r, Dlist **tail_r);	
void subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **head_r, Dlist **tail_r);
void division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **head_r, Dlist **tail_r);
#endif
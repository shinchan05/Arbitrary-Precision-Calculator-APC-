#include"dll.h"
#include<stdio.h>
#include <stdlib.h>

void multiplication(Dlist **head1, Dlist **tail1,
                    Dlist **head2, Dlist **tail2,
                    Dlist **res_head, Dlist **res_tail)
{
    delete_list(res_head, res_tail);

    // If any number is 0
    if ((*head1)->data == 0 && (*head1)->next == NULL ||
        (*head2)->data == 0 && (*head2)->next == NULL)
    {
        insert_last(res_head, res_tail, 0);
        return;
    }

    Dlist *t2 = *tail2;//traversing second number from last
    int pos = 0;

    Dlist *final_head = NULL;
    Dlist *final_tail = NULL;

    while (t2)//for each digit of second number
    {
        Dlist *temp_head = NULL;
        Dlist *temp_tail = NULL;

        // Add zeros for position shift
        for (int i = 0; i < pos; i++)
            insert_last(&temp_head, &temp_tail, 0);//shifting

        int carry = 0;
        Dlist *t1 = *tail1;

        while (t1)
        {
            int mul = (t1->data * t2->data) + carry;//multiplying digits
            carry = mul / 10;
            insert_at_first(&temp_head, &temp_tail, mul % 10);
            t1 = t1->prev;
        }

        if (carry)//if carry is left
            insert_at_first(&temp_head, &temp_tail, carry);//insert carry

        // Add to final result
        if (!final_head)
        {
            copy_list(&temp_head, &temp_tail,
                      &final_head, &final_tail);
        }
        else
        {
            Dlist *sum_head = NULL;
            Dlist *sum_tail = NULL;

            add(&final_head, &final_tail,
                &temp_head, &temp_tail,
                &sum_head, &sum_tail);

            delete_list(&final_head, &final_tail);
            final_head = sum_head;
            final_tail = sum_tail;
        }

        delete_list(&temp_head, &temp_tail);//free temp list
        t2 = t2->prev;
        pos++;
    }

    copy_list(&final_head, &final_tail, res_head, res_tail);
    delete_list(&final_head, &final_tail);
}

#include"dll.h"
#include<stdio.h>
#include <stdlib.h>


void division(Dlist **head1, Dlist **tail1,
              Dlist **head2, Dlist **tail2,
              Dlist **res_head, Dlist **res_tail)
{
    delete_list(res_head, res_tail);

    // Check for division by zero
    if (*head2 == NULL || ((*head2)->data == 0 && (*head2)->next == NULL))
    {
        printf("ERROR: Division by zero\n");
        return;
    }

    
    if (*head1 == NULL || ((*head1)->data == 0 && (*head1)->next == NULL))
    {
        insert_last(res_head, res_tail, 0);
        return;
    }

   
    Dlist *temp_head = NULL;
    Dlist *temp_tail = NULL;
    copy_list(head1, tail1, &temp_head, &temp_tail);//copying dividend to temp list

    int count = 0;

    while (compare_lists(temp_head, *head2) >= 0)//while temp >= divisor
    {
        Dlist *new_head = NULL;
        Dlist *new_tail = NULL;

        subtraction(&temp_head, &temp_tail,head2, tail2,&new_head, &new_tail);//temp - divisor

        delete_list(&temp_head, &temp_tail);//free old temp
        temp_head = new_head;
        temp_tail = new_tail;

        count++;
    }

    if (count == 0)
    {
        insert_last(res_head, res_tail, 0);
    }
    else
    {
        while (count)
        {
            insert_at_first(res_head, res_tail, count % 10);
            count /= 10;
        }
    }

    delete_list(&temp_head, &temp_tail);
}

#include "dll.h"
#include <stdio.h>

int print_list(Dlist *head)
{
    if (!head)
        return LIST_EMPTY;//if list is empty

    while (head)
    {
        printf("%d", head->data);
        head = head->next;
    }
    return SUCCESS;
}
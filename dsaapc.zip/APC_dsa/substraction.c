#include "dll.h"
#include<stdio.h>   
#include <stdlib.h>


void subtraction(Dlist **head1, Dlist **tail1,Dlist **head2, Dlist **tail2,Dlist **res_head, Dlist **res_tail)
{
    Dlist *copy_head = NULL;
    Dlist *copy_tail = NULL;

    copy_list(head1, tail1, &copy_head, &copy_tail);//copying minuend to temp list

    Dlist *temp1 = copy_tail;
    Dlist *temp2 = *tail2;

    int borrow = 0, diff;

    while (temp1)//traversing minuend
    {
        int d1 = temp1->data - borrow;//adjusting minuend digit with borrow
        int d2 = (temp2) ? temp2->data : 0;//if second number is shorter

        if (d1 < d2)
        {
            d1 += 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        diff = d1 - d2;
        insert_at_first(res_head, res_tail, diff);//inserting difference digit

        temp1 = temp1->prev;//move to next digit of minuend
        if (temp2)
            temp2 = temp2->prev;//move to next digit of subtrahend
    }

    
    while (*res_head && (*res_head)->next && (*res_head)->data == 0)//removing leading zeros
        delete_first(res_head);

  
    delete_list(&copy_head, &copy_tail);//free temp list
}

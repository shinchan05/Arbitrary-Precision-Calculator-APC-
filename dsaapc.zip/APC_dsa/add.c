#include "dll.h"
#include<stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>


void add(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **res_head, Dlist **res_tail)
{
    *res_head = NULL;
    *res_tail = NULL;
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;
    int carry = 0, digit = 0;
    if (!*head1 && !*head2)
{
    insert_at_first(res_head, res_tail, 0);//result is 0
    return;
}
    while(temp1 || temp2)//traversing both numbers
    {
        if(temp1 && temp2)//both numbers have digits
        {
            digit = temp1 -> data + temp2 -> data + carry;//adding digits along with carry
            if(digit > 9)
            {
                carry = digit / 10;
                digit %= 10;
            }
            else
            {
                carry = 0;
            }
            temp1 = temp1 -> prev;// move to next digit
            temp2 = temp2 -> prev;// move to next digit
        }
        else if(temp2 == NULL)
        {
            digit = temp1 ->data + carry;//only first number has digits
            if(digit > 9)
            {
                carry = digit / 10;
                digit %= 10;
            }
            else
            {
                carry = 0;
            }
            temp1 = temp1 -> prev;// move to next digit
        }
        else if(temp1 == NULL)
        {
            digit = temp2 -> data + carry;//only second number has digits
            if(digit > 9)
            {
                carry = digit / 10;
                digit %= 10;
            }
            else
            {
                carry = 0;
            }
            temp2 = temp2 -> prev;// move to next digit
        }
        insert_at_first(res_head, res_tail, digit);//inserting digit to result
    }
    if(carry)
    insert_at_first(res_head, res_tail, carry);//inserting remaining carry
    while(*res_head && (*res_head) -> next && (*res_head) -> data == 0)//removing leading zeros
    {
        delete_first(res_head);
    }
}
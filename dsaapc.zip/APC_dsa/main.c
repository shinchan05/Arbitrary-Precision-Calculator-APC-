// NAME : Y.Manjunath Reddy
// ROLL NO : 25026-A
//This projects works as a calculator for large integers using doubly linked lists.
#include "dll.h"
#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
//for deleting leading zeros
int delete_first(Dlist **head)
{
    if (*head == NULL)
        return FAILURE;

    Dlist *temp = *head;
    *head = (*head)->next;

    if (*head != NULL)
        (*head)->prev = NULL;   

    free(temp);
    return SUCCESS;
}

int main(int argc,char *argv[])
{
    Dlist *head = NULL;
    Dlist *head2 = NULL;
    Dlist *tail = NULL;
    Dlist *tail2 = NULL;
    Dlist *result_head = NULL;
    Dlist *result_tail = NULL;
//for argument count check
  if (argc != 4)
{
    printf("Usage: ./a.out <num1> <operator> <num2>\n");
    return 0;
}
//forchecking valid operator
 if((argv[2][0] != '+' && argv[2][0] != '-' && argv[2][0] != 'x' && argv[2][0] != '/') || (argv[2][1] != '\0'))
    {
        printf("ERROR:Invalid operator\n");
        return 0;
    } 
//for inserting first number into dll
int n1_sign_char = 0;
    int n1_sign = POSITIVE;
if(argv[1][0] == '+')
    {
        n1_sign_char++;
    }
    if(argv[1][0] == '-')
    {
        n1_sign = NEGATIVE;
        n1_sign_char++;
    }
    //printf("hlo");
  char *num=argv[1]; 
  for(int i=n1_sign_char;num[i]!='\0';i++)
  {
    if(isdigit(argv[1][i]))
        {
              int digit=num[i]-'0';
            (insert_last(&head, &tail, digit));
        }
    else
        {
          printf("Invalid 1st operand ⚠️\n");
          return 0;
        }
    
  }
  //removing leading zeros
  while(head && head -> next && head -> data == 0)
    {
        delete_first(&head);
    }
 //for inserting second number into dll
  char op = argv[2][0];
  char *num2=argv[3];
    int n2_sign_char = 0;
    int n2_sign = POSITIVE;
if(argv[3][0] == '+')
    {
        n2_sign_char++;
    }
if(argv[3][0] == '-')
    {
        n2_sign = NEGATIVE;
        n2_sign_char++;
    }
for(int i=n2_sign_char;num2[i]!='\0';i++)
  {
    if(isdigit(argv[3][i]))
        {
              int digit=num2[i]-'0';
            (insert_last(&head2, &tail2, digit));
        }
    else
        {
          printf("Invalid 2nd operand \n");
          return 0;
        }  
  }
  //removing leading zeros
   while(head2 && head2 -> next && head2 -> data == 0)
    {
        delete_first(&head2);
    }
switch (op)
  {
    
        case '+':
                {
                    //perform addition operation
                    printf("Addition operation\n");
                    printf("%s + %s = ", argv[1], argv[3]);

                    //delete_list(&result_head, &result_tail);

                    if (n1_sign == n2_sign)//same sign nrml ADDITION
                    {
                        add(&head, &tail, &head2, &tail2, &result_head, &result_tail);

                        if (n1_sign == NEGATIVE)
                            printf("-");
                    }
                    else
                    {
                        int cmp = compare_lists(head, head2);//compare the 2 numbers

                        if (cmp < 0)
                            swap_operand(&head, &tail, &head2, &tail2);//swap if first is smaller

                        subtraction(&head, &tail, &head2, &tail2, &result_head, &result_tail);//subtract smaller from larger

                        /* Sign decision */
                        if ((n1_sign == NEGATIVE && cmp >= 0) || (n2_sign == NEGATIVE && cmp < 0))
                        {
                            printf("-");
                        }
                    }
                    //printf("hlo");
                    print_list(result_head);//print result
                    printf("\n");
                    break;
                }

    case '-':
    delete_list(&result_head, &result_tail);//clear previous result
        printf("Operation : subtraction\n");//print operation
                    printf("%s - %s = ", argv[1], argv[3]);
                    if(strcmp(argv[1], argv[3]) == 0)//if both operands are equal
                    {
                        insert_at_first(&result_head, &result_tail, 0);//result is 0
                        print_list(result_head);
                        printf("\n");
                        break;
                    }
                    int swap = 0;
                    if(list_length(head) < list_length(head2))//if first operand is smaller
                    {
                        swap_operand(&head, &tail, &head2, &tail2);//swap operands
                        swap = 1;
                    }
                    else if(list_length(head) == list_length(head2))//if both operands have same length
                    {
                        for(int i = 0; i < strlen(argv[1]); i++)//compare digit by digit
                        {
                            if(argv[1][i] < argv[3][i])
                            {
                                swap_operand(&head, &tail, &head2, &tail2);//swap if first is smaller
                                swap = 1;
                                break;
                            }
                        }
                    }
                    //both operands have same sign
                    if(n1_sign == n2_sign)
                    {
                        if(n1_sign == POSITIVE)
                        {
                            if(swap)
                            printf("-");
                            subtraction(&head, &tail, &head2, &tail2, &result_head, &result_tail);
                            print_list(result_head);
                            printf("\n");
                        }
                        else
                        {
                            if(swap == 0)
                            printf("-");
                            subtraction(&head, &tail, &head2, &tail2, &result_head, &result_tail);
                            print_list(result_head);
                            printf("\n");
                        }
                        break;
                    }
                    //operands have different sign
                    else
                    {
                        if(n1_sign == POSITIVE)
                        {
                            add(&head, &tail, &head2, &tail2, &result_head, &result_tail);
                            print_list(result_head);
                            printf("\n");
                        }
                        else
                        {
                            printf("-");
                            add(&head, &tail, &head2, &tail2, &result_head, &result_tail);
                            print_list(result_head);
                            printf("\n");
                        }
                    }
                    break;
                        case 'x'://multiplication operation
                        case 'X'://multiplication operation (user can enter either 'x' or 'X' so handle both without break so fallthrough)
                        case '*':
                        {
                            printf("Multiplication operation\n");

                            delete_list(&result_head, &result_tail);//clear previous result

                            multiplication(&head, &tail, &head2, &tail2,&result_head, &result_tail);//perform multiplication

                            int sign = (n1_sign == n2_sign) ? POSITIVE : NEGATIVE;//sign of result

                            printf("%s * %s = ", argv[1], argv[3]);//print operation

                            if (sign == NEGATIVE)
                                printf("-");

                            print_list(result_head);//print result
                            printf("\n");

                            break;
                        }
                        case '/':
                        {
                            if (head2->data == 0 && head2->next == NULL)//check for division by zero
                            {
                                printf("Invalid operand.. Divisor cannot be zero.\n");
                                break;
                            }

                            int quotient_sign = (n1_sign == n2_sign) ? POSITIVE : NEGATIVE;//sign of quotient

                            division(&head, &tail, &head2, &tail2,&result_head, &result_tail);//perform division

                            printf("%s / %s = ", argv[1], argv[3]);

                            if (quotient_sign == NEGATIVE)
                                printf("-");

                            print_list(result_head);
                            printf("\n");

                            break;
                        }


    default:
        printf("Invalid operator\n");
        break;
}
}
  
//function to swap operands
  void swap_operand(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2)
{
    Dlist *temp = *head1;
    *head1 = *head2;
    *head2 = temp;

    temp = *tail1;
    *tail1 = *tail2;
    *tail2 = temp;
}
//function to insert at end of dll
int insert_at_first(Dlist **head, Dlist **tail, int data)
{
    Dlist *new = malloc(sizeof(Dlist));
    if (!new) return FAILURE;

    new->data = data;
    new->prev = NULL;
    new->next = *head;

    if (*head)
        (*head)->prev = new;
    else
        *tail = new;

    *head = new;
    return SUCCESS;
}
//function to insert at end of dll
int delete_list(Dlist **head, Dlist **tail)
{
    if (*head == NULL)
        return FAILURE;

    Dlist *temp;
    while (*head)
    {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }
    *tail = NULL;
    return SUCCESS;
}


/* Function to copy data of one DLL to another. */
void copy_list(Dlist **head, Dlist **tail, Dlist **copy_head, Dlist **copy_tail)
{
    if(*head == NULL)
    {
        return;
    }
    delete_list(copy_head, copy_tail);

    Dlist *temp = *head;
    while(temp)
    {
        insert_last(copy_head, copy_tail, temp -> data);
        temp = temp -> next;
    }

}
//function to get length of dll
int list_length(Dlist *head)
{
    int length = 0;
    Dlist *temp = head;
    while(temp)
    {
        length++;
        temp = temp -> next;
    }
    return length;


}
//function to compare two dll numbers
int compare_lists(Dlist *head1, Dlist *head2)
{
    int len1 = list_length(head1);
    int len2 = list_length(head2);

    if (len1 > len2)
        return 1;
    if (len1 < len2)
        return -1;

    while (head1 && head2)
    {
        if (head1->data > head2->data)
            return 1;
        else if (head1->data < head2->data)
            return -1;

        head1 = head1->next;
        head2 = head2->next;
    }

    return 0;
}
